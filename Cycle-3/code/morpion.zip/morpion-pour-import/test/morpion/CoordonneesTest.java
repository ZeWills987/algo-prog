package morpion;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

/**
 *
 */
public class CoordonneesTest {

    @Test
    public void testEstDansPlateau() {
        assertTrue(new Coordonnees(0, 0).estDansPlateau(14));
        assertTrue(new Coordonnees(13, 13).estDansPlateau(14));
        assertTrue(new Coordonnees(0, 1).estDansPlateau(14));
        assertFalse(new Coordonnees(-1, 1).estDansPlateau(14));
        assertTrue(new Coordonnees(7, 13).estDansPlateau(14));
        assertFalse(new Coordonnees(7, 14).estDansPlateau(14));
        assertTrue(new Coordonnees(13, 0).estDansPlateau(14));
        assertFalse(new Coordonnees(14, 0).estDansPlateau(14));
        assertTrue(new Coordonnees(7, 0).estDansPlateau(14));
        assertFalse(new Coordonnees(7, -1).estDansPlateau(14));
        assertTrue(new Coordonnees(0, 1).estDansPlateau(2));
        assertFalse(new Coordonnees(0, 1).estDansPlateau(1));
    }

    @Test
    public void testSuivante() {
        assertEquals(new Coordonnees(5, 4),
                new Coordonnees(4, 4).suivante(Direction.SUD));
        assertEquals(new Coordonnees(2, 2),
                new Coordonnees(1, 1).suivante(Direction.NORD_OUEST));
        assertEquals(new Coordonnees(-1, -1),
                new Coordonnees(0, 0).suivante(Direction.NORD_OUEST));
        assertEquals(new Coordonnees(199, 201),
                new Coordonnees(200, 200).suivante(Direction.NORD_EST));
    }
}
