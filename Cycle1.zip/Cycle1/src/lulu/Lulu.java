/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lulu;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author William Tchang
 */
public class Lulu {

    /**
     * Niveau de difficulté minimum.
     */
    final static int DIFFICULTE_MIN = 1;
    /**
     * Niveau de difficulté maximum.
     */
    final static int DIFFICULTE_MAX = 3;

    /**
     * Nombre de min-jeux.
     */
    final static int NOMBRE_JEUX = 4;
    
    /**
     * Taille du plateau de course.
     */
    final static int TAILLE_PLATEAU_COURSE = 10;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        jeuAventure_menuPrincipal();
    }

    /**
     * Menu pricipale du jeu Lulu.
     */
    static void jeuAventure_menuPrincipal() {
        int partiesGagnees = 0;
        int partiesJouees = 0;
        int reponse;
        boolean jeuTermine = false;
        do {
            afficheMenu();
            reponse = jeuAventure_saisirNombreIntervalle(1, NOMBRE_JEUX + 1);
            if (reponse != 5) {
                if (choixJeu(reponse)) {
                    partiesGagnees++;
                }
                partiesJouees++;
            } else {
                jeuTermine = true;
            }
        } while (!jeuTermine);
        afficherFinJeu(partiesJouees, partiesGagnees);
    }

    /**
     * Choisit le min-jeu à jouer.
     *
     * @param jeu le choix du mini-jeux
     * @return vrai si le jeu est terminer.
     */
    static boolean choixJeu(int jeu) {
        boolean partieGagnée = false;
        switch (jeu) {
            case 1 -> {
                partieGagnée = jeuSuite_principal();
            }
            case 2 -> {
                partieGagnée = jeuTrain_principal();
            }
            case 3 -> {
                partieGagnée = jeuCourse_principal();
            }
            case 4 -> {
                //partieGagnée = jeuDevin_principal();
            }
            default -> {
                partieGagnée = false;
            }
        }
        return partieGagnée;
    }

    ///////////////////////////Jeu Suite//////////////////////////////////////////////
    /**
     * Programme principale du jeu de suite.
     *
     * @return vrai si le jeu est reussi
     */
    static boolean jeuSuite_principal() {
        System.out.println("Jeu Suite");
        System.out.println("");
        boolean goodJob;
        jeuSuite_afficherRegles();
        int niveau = jeuAventure_saisirNiveauDifficulte();
        if (jeuSuite_partie(niveau)) {
            System.out.println("Bravo !!!");
            goodJob = true;
        } else {
            System.out.println("Perdue, reessaie encore !!!");
            goodJob = false;
        }
        return goodJob;
    }

    /**
     * Affichage des règle du jeu de suite.
     */
    static void jeuSuite_afficherRegles() {
        System.out.println("Les regles : comprendre la suite logique et indiquez quel est la prochaine forme.");
    }

    /**
     * Demarage de la session de jeu suite
     *
     * @param niveauDifficulte la difficulter du jeu
     * @return vrai si il repond bien
     */
    static boolean jeuSuite_partie(int niveauDifficulte) {
        boolean jeuReussi = false;
        char verification = jeuSuite_formeCorrecte(niveauDifficulte);
        switch (niveauDifficulte) {
            case 1 -> {
                jeuSuite_afficherFormes('T', 'C', 'T', 'C', ' ');
                jeuReussi = (jeuSuite_saisirForme() == verification);
            }
            case 2 -> {
                jeuSuite_afficherFormes('C', 'C', 'T', 'T', ' ');
                jeuReussi = (jeuSuite_saisirForme() == verification);
            }
            case 3 -> {
                jeuSuite_afficherFormes('T', 'C', 'P', 'T', ' ');
                jeuReussi = (jeuSuite_saisirForme() == verification);
            }
        }
        return jeuReussi;
    }

    /**
     * Affiche la suite logique en fonction du niveau de difficulté.
     *
     * @param c1 1er caractère de la suite
     * @param c2 2nd caractère de la suite
     * @param c3 3e caractère de la suite
     * @param c4 4e caractère de la suite
     * @param c5 5e caractère de la suite
     */
    static void jeuSuite_afficherFormes(char c1, char c2, char c3, char c4, char c5) {
        System.out.println("  - - - - - \n"
                + " |" + c1 + "|" + c2 + "|" + c3 + "|" + c4 + "|" + c5 + "|\n"
                + "  - - - - - ");
    }

    /**
     * Récupère le caractère saisie par l'utilisateur.
     *
     * @return un caractère
     */
    static char jeuSuite_saisirForme() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Quel symbole suit le plateau ");
        System.out.println("Saisissez une lettre 't'(trefle) ou 'c'(coeur) ou 'p'(pique):");
        String str = sc.nextLine();
        char c = str.charAt(0);
        return c;
    }

    /**
     * Vérifie les réponse de l'utilisateur en fonctions du niveau.
     *
     * @param niveauDifficulte la difficulté choisie
     * @return le caractère corespondant au niveau
     */
    static char jeuSuite_formeCorrecte(int niveauDifficulte) {
        char juste = ' ';
        switch (niveauDifficulte) {
            case 1 -> {
                juste = 't';
            }
            case 2 -> {
                juste = 'c';
            }
            case 3 -> {
                juste = 'c';
            }
        }
        return juste;
    }

    ///////////////////////////Jeu Train/////////////////////////////////////
    /**
     * Fonction principale du Jeu de Train avec afficgae des règle et
     * récupération et vérification de la réussite du jeu
     *
     * @return si le jeu réussi ou non
     */
    static boolean jeuTrain_principal() {
        System.out.println("Jeu Train");
        System.out.println("");
        boolean goodJob;
        jeuTrain_afficherRegles();
        int niveau = jeuAventure_saisirNiveauDifficulte();
        boolean jeuReussi = jeuTrain_partie(niveau);
        if (jeuReussi) {
            System.out.println("Bravo !!!");
            goodJob = true;
        } else {
            goodJob = false;
        }
        return goodJob;
    }

    /**
     * Affichaege des règle du Jeu de Train
     */
    static void jeuTrain_afficherRegles() {
        System.out.println("Voici les regles : comptez le nombre de passagers qui attendent le train et saisir le nombre de wagons");
    }

    /**
     *
     *
     * @param niveau
     * @return
     */
    static boolean jeuTrain_partie(int niveau) {
        boolean jeuReussi = false;
        Random random = new Random();
        int mini = 1;
        int maxi, nbpassager;
        //char verification = jeuSuite_formeCorrecte(niveau);
        switch (niveau) {
            case 1 -> {
                maxi = 2;
                nbpassager = random.nextInt(maxi - mini + 1) + mini;
                jeuTrain_afficherFormes(":)", nbpassager);
                jeuReussi = jeuTrain_afficheTrainCorrect(nbpassager, jeuTrain_saisirNombreWagon());
            }
            case 2 -> {
                maxi = 3;
                nbpassager = random.nextInt(maxi - mini + 1) + mini;
                jeuTrain_afficherFormes(":)", nbpassager);
                jeuReussi = jeuTrain_afficheTrainCorrect(nbpassager, jeuTrain_saisirNombreWagon());
            }
            case 3 -> {
                maxi = 4;
                nbpassager = random.nextInt(maxi - mini + 1) + mini;
                jeuTrain_afficherFormes(":)", nbpassager);
                jeuReussi = jeuTrain_afficheTrainCorrect(nbpassager, jeuTrain_saisirNombreWagon());
            }
        }
        return jeuReussi;
    }

    /**
     * Affichage des smiles (personnes).
     *
     * @param niveau difficulté du jeu
     */
    static void jeuTrain_afficherFormes(String car, int nbSmilles) {
        String space = " ";
        String result = "";
        for (int i = 0; i < nbSmilles; i++) {
            result += car + space;
        }
        System.out.println(result);
    }

    /**
     * Récupère le nombre de wagons choisi par l'utilisateur
     *
     * @return le nombre de wagons
     */
    static int jeuTrain_saisirNombreWagon() {
        System.out.println("Combien de wagon faut-il ajouter ?");
        Scanner sc = new Scanner(System.in);
        int wagons = sc.nextInt();
        while (wagons == 0) {
            System.out.println("Combien de wagon faut-il ajouter ?");
            wagons = sc.nextInt();
        }
        return wagons;
    }

    /**
     * Affichage et vérification du jeu Train
     *
     * @param nbPassager le nombre d'usager
     * @return le nombre d'usager restant ou 0 ou -1
     */
    static boolean jeuTrain_afficheTrainCorrect(int nbPassager, int nbWagon) {
        int wagons_vide = nbWagon - nbPassager;// Nombre de wagons vides
        int passagerRestant = nbPassager - nbWagon;//Nombre d'usager restant
        boolean correct = false;
        int resultat;
        //Si le joueur à juste
        if (nbPassager == nbWagon) {
            correct = true;
        }
        // Si pas il y a pas asser de wagons 
        if (nbPassager > nbWagon) {
            nbPassager = nbWagon;
        }
        //Si il y a trop de wagons
        if (nbPassager < nbWagon) {
            for (int i = 0; i < wagons_vide; i++) {
                System.out.println(""
                        + "  —————\n"
                        + "  |   |\n"
                        + "  |   |\n"
                        + "  |   |\n"
                        + "  —————\n"
                        + "    |  "
                );
            }
        }
        //Affichage dans tout les cas du jeu
        for (int i = 1; i <= nbPassager; i++) {
            System.out.println(""
                    + "  —————\n"
                    + "  |   |\n"
                    + "  | :)|\n"
                    + "  |   |\n"
                    + "  —————\n"
                    + "    |  "
            );
        }
        System.out.println("    |\n"
                + "   |||\n"
                + " .-----.\n"
                + " |o< >o|\n"
                + "//// \\\\\\\\\n"
                + "  /---\\ \n"
                + " /-----\\"
        );
        //Message si il reste des passages
        if (passagerRestant > 0) {
            System.out.println("Perdue !!! Il manque " + passagerRestant + " usager(s) à quai :");
            jeuTrain_afficherFormes(":)", passagerRestant);
            System.out.println("");
        }
        //Message si il y a trop de 
        if (nbPassager < nbWagon) {
            System.out.println("Perdue !!! Il y a trop de wagons");
        }
        return correct;
    }

    ///////////////////////Jeu Course////////////////////////////
    static boolean jeuCourse_principal() {
        jeuCourse_afficheCourse(1,5,10);
        return false;
    }

    /**
     * Affichage des règles du Jeu de Course
     */
    static void jeuCourse_affichageRègles() {
        
    }

    /**
     * Affiche le plateau de course
     *
     * @param posJ1 la position sur le plateau du 1er coureur
     * @param posJ2 la position sur le plateau du 2nd coureur
     * @param posJ3 la position sur le plateau du 3e coureur
     */
    static void jeuCourse_afficheCourse(int posJ1, int posJ2, int posJ3) {
        System.out.println(" - - - - - - - - - ARRIVEE\n");
        jeuCourse_afficheLigne('♥',posJ1,TAILLE_PLATEAU_COURSE);
        jeuCourse_afficheLigne('♣',posJ2,TAILLE_PLATEAU_COURSE);
        jeuCourse_afficheLigne('♠',posJ3,TAILLE_PLATEAU_COURSE);
    }
    
    /**
     * Affiche une ligne du plateau de course
     * 
     * @param car le symbole du représentatif du coureur
     * @param pos la position du coureur sur le plateau
     * @param taille la taille du plateau de course
     */
    static void jeuCourse_afficheLigne(char car,int pos,int taille){
        String ligne="";
        for(int i = 1;i<pos;i++){
            ligne = ligne+"| ";
        }
        ligne=ligne+"|"+car;
        for(int i = 1;i<(taille+1)-pos;i++){
            ligne=ligne+"| ";
        }
        ligne=ligne+"|";
        System.out.println(ligne);
    }

    ////////////////////////Jeu Devin///////////////////////////////
//    static boolean jeuDevin_principal() {
//        return false;
//    }
/////////////////////////Fonction Jeu Aventure//////////////////////
    /**
     * Récupère un nombre d'une intervalle donnée.
     *
     * @return nombre saisie
     */
    static int jeuAventure_saisirNombreIntervalle(int min, int max) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Saisir une valeur entre " + min + " et " + max + " :");
        int num = sc.nextInt();
        while (!(num >= min && num <= max)) {
            System.out.println("Saisir une valeur entre " + min + " et " + max + " :");
            num = sc.nextInt();
        }
        return num;
    }

    /**
     * Récupère le niveau de difficulté.
     *
     * @return le niveau
     */
    static int jeuAventure_saisirNiveauDifficulte() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Saisir un niveau de difficulter entre " + DIFFICULTE_MIN + " et " + DIFFICULTE_MAX);
        int num = sc.nextInt();
        System.out.println("");
        System.out.println("Niveau " + num + " :");
        while (!(num >= DIFFICULTE_MIN && num <= DIFFICULTE_MAX)) {
            System.out.println("Saisir un niveau de difficulter entre " + DIFFICULTE_MIN + " et " + DIFFICULTE_MAX);
            num = sc.nextInt();
            System.out.println("");
            System.out.println("Niveau " + num + " :");
        }
        return num;
    }

///////////////////////////////////////////////////////////////////////////////
/*Affichage Graphique*/
    /**
     * Affichage du menu
     *
     */
    static void afficheMenu() {
        System.out.println("           \\\\\\||||||////\n"
                + "            \\\\  ~ ~  //\n"
                + "             (  @ @  )\n"
                + "    ______ oOOo-(_)-oOOo___________\n"
                + "\n"
                + "\t (1) trouver la suite " + "\n"
                + "\t (2) jeu du train " + "\n"
                + "\t (3) course en ligne " + "\n"
                + "\t (4) le devin " + "\n"
                + "\t (5) quitter " + "\n"
                + "\n"
                + "    _____________Oooo._____________\n"
                + "       .oooO     (   )\n"
                + "        (   )     ) /\n"
                + "         \\ (     (_/\n"
                + "          \\_)");
    }

    /**
     * Affichage de la fin du jeu.
     */
    static void afficherFinJeu(int nbParties, int partiesGagnée) {
        System.out.println("   .____________________.\n"
                + "   |.------------------.|\n"
                + "   ||                  ||\n"
                + "   ||    GAME OVER     ||\n"
                + "   ||Parties jouées: " + nbParties + " ||\n"
                + "   ||                  ||\n"
                + "   ||Parties gagnées: " + partiesGagnée + "||\n"
                + "   ||__________________||\n"
                + "   /.-.-.-.-.-.-.-.-.-.-\\\n"
                + "  /.-.-.-.-.-.-.-.-.-.-.-\\\n"
                + " /.-.-.-.-.-.-.-.-.-.-.-.-\\\n"
                + "/______/__________\\___o____\\    \n"
                + "\\__________________________"
                + "/");
    }

}
