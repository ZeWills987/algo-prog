package odomo;

/**
 * Tests portant sur la classe Jardin.
 */
public class JardinTest {
    
}
