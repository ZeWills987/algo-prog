package lulu;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author William Tchang
 */
public class lulu {

    /**
     * Niveau de difficulté minimum.
     */
    final static int DIFFICULTE_MIN = 1;
    /**
     * Niveau de difficulté maximum.
     */
    final static int DIFFICULTE_MAX = 3;

    /**
     * Nombre de min-jeux.
     */
    final static int NOMBRE_JEUX = 4;

    /**
     * Taille du plateau de course.
     */
    final static int TAILLE_PLATEAU_COURSE = 10;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        jeuAventure_menuPrincipal();
    }

    /**
     * Menu pricipale du jeu Lulu.
     */
    static void jeuAventure_menuPrincipal() {
        int partiesGagnees = 0;
        int partiesJouees = 0;
        int reponse;
        boolean jeuTermine = false;
        do {
            afficheMenu();
            reponse = jeuAventure_saisirNombreIntervalle(1, NOMBRE_JEUX + 1);
            if (reponse != 5) {
                if (choixJeu(reponse)) {
                    partiesGagnees++;
                }
                partiesJouees++;
            } else {
                jeuTermine = true;
            }
        } while (!jeuTermine);
        afficherFinJeu(partiesJouees, partiesGagnees);
    }

    /**
     * Choisit le min-jeu à jouer.
     *
     * @param jeu le choix du mini-jeux
     * @return vrai si le jeu est terminer.
     */
    static boolean choixJeu(int jeu) {
        boolean partieGagnée = false;
        switch (jeu) {
            case 1: {
                partieGagnée = jeuSuite_principal();
                break;
            }
            case 2: {
                partieGagnée = jeuTrain_principal();
                break;
            }
            case 3: {
                partieGagnée = jeuCourse_principal();
                break;
            }
            case 4: {
                partieGagnée = jeuDevin_principal();
                break;
            }
            default: {
                partieGagnée = false;
                break;
            }
        }
        return partieGagnée;
    }

    ///////////////////////////Jeu Suite//////////////////////////////////////////////
    /**
     * Programme principale du jeu de suite.
     *
     * @return vrai si le jeu est reussi
     */
    static boolean jeuSuite_principal() {
        System.out.println("Jeu Suite");
        System.out.println("");
        boolean goodJob;
        jeuSuite_afficherRegles();
        int niveau = jeuAventure_saisirNiveauDifficulte();
        if (jeuSuite_partie(niveau)) {
            System.out.println("Bravo !!!");
            goodJob = true;
        } else {
            System.out.println("Perdue, reessaie encore !!!");
            goodJob = false;
        }
        return goodJob;
    }

    /**
     * Affichage des règle du jeu de suite.
     */
    static void jeuSuite_afficherRegles() {
        System.out.println("Les regles : comprendre la suite logique et indiquez quel est la prochaine forme.");
    }

    /**
     * Demarage de la session de jeu suite
     *
     * @param niveauDifficulte la difficulter du jeu
     * @return vrai si il repond bien
     */
    static boolean jeuSuite_partie(int niveauDifficulte) {
        boolean jeuReussi = false;
        char verification = jeuSuite_formeCorrecte(niveauDifficulte);
        switch (niveauDifficulte) {
            case 1: {
                jeuSuite_afficherFormes('T', 'C', 'T', 'C', ' ');
                jeuReussi = (jeuSuite_saisirForme() == verification);
                break;
            }
            case 2: {
                jeuSuite_afficherFormes('C', 'C', 'T', 'T', ' ');
                jeuReussi = (jeuSuite_saisirForme() == verification);
                break;
            }
            case 3: {
                jeuSuite_afficherFormes('T', 'C', 'P', 'T', ' ');
                jeuReussi = (jeuSuite_saisirForme() == verification);
                break;
            }
        }
        return jeuReussi;
    }

    /**
     * Affiche la suite logique en fonction du niveau de difficulté.
     *
     * @param c1 1er caractère de la suite
     * @param c2 2nd caractère de la suite
     * @param c3 3e caractère de la suite
     * @param c4 4e caractère de la suite
     * @param c5 5e caractère de la suite
     */
    static void jeuSuite_afficherFormes(char c1, char c2, char c3, char c4, char c5) {
        System.out.println("  - - - - - \n"
                + " |" + c1 + "|" + c2 + "|" + c3 + "|" + c4 + "|" + c5 + "|\n"
                + "  - - - - - ");
    }

    /**
     * Récupère le caractère saisie par l'utilisateur.
     *
     * @return un caractère
     */
    static char jeuSuite_saisirForme() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Quel symbole suit le plateau ");
        System.out.println("Saisissez une lettre 't'(trefle) ou 'c'(coeur) ou 'p'(pique):");
        String str = sc.nextLine();
        char c = str.charAt(0);
        return c;
    }

    /**
     * Vérifie les réponse de l'utilisateur en fonctions du niveau.
     *
     * @param niveauDifficulte la difficulté choisie
     * @return le caractère corespondant au niveau
     */
    static char jeuSuite_formeCorrecte(int niveauDifficulte) {
        char juste = ' ';
        switch (niveauDifficulte) {
            case 1: {
                juste = 't';
                break;
            }
            case 2: {
                juste = 'c';
                break;
            }
            case 3: {
                juste = 'c';
                break;
            }
        }
        return juste;
    }

    ///////////////////////////Jeu Train/////////////////////////////////////
    /**
     * Fonction principale du Jeu de Train avec afficgae des règle et
     * récupération et vérification de la réussite du jeu
     *
     * @return si le jeu réussi ou non
     */
    static boolean jeuTrain_principal() {
        System.out.println("Jeu Train");
        System.out.println("");
        boolean goodJob;
        jeuTrain_afficherRegles();
        int niveau = jeuAventure_saisirNiveauDifficulte();
        boolean jeuReussi = jeuTrain_partie(niveau);
        if (jeuReussi) {
            System.out.println("Bravo !!!");
            goodJob = true;
        } else {
            goodJob = false;
        }
        return goodJob;
    }

    /**
     * Affichaege des règle du Jeu de Train
     */
    static void jeuTrain_afficherRegles() {
        System.out.println("Voici les regles : comptez le nombre de passagers qui attendent le train et saisir le nombre de wagons");
    }

    /**
     *
     *
     * @param niveau
     * @return
     */
    static boolean jeuTrain_partie(int niveau) {
        boolean jeuReussi = false;
        Random random = new Random();
        int mini = 1;
        int maxi, nbpassager;
        //char verification = jeuSuite_formeCorrecte(niveau);
        switch (niveau) {
            case 1: {
                maxi = 2;
                nbpassager = random.nextInt(maxi - mini + 1) + mini;
                jeuTrain_afficherFormes(":)", nbpassager);
                jeuReussi = jeuTrain_afficheTrainCorrect(nbpassager, jeuTrain_saisirNombreWagon());
                break;
            }
            case 2: {
                maxi = 3;
                nbpassager = random.nextInt(maxi - mini + 1) + mini;
                jeuTrain_afficherFormes(":)", nbpassager);
                jeuReussi = jeuTrain_afficheTrainCorrect(nbpassager, jeuTrain_saisirNombreWagon());
                break;
            }
            case 3: {
                maxi = 4;
                nbpassager = random.nextInt(maxi - mini + 1) + mini;
                jeuTrain_afficherFormes(":)", nbpassager);
                jeuReussi = jeuTrain_afficheTrainCorrect(nbpassager, jeuTrain_saisirNombreWagon());
                break;
            }
        }
        return jeuReussi;
    }

    /**
     * Affichage des smiles (personnes).
     *
     * @param niveau difficulté du jeu
     */
    static void jeuTrain_afficherFormes(String car, int nbSmilles) {
        String space = " ";
        String result = "";
        for (int i = 0; i < nbSmilles; i++) {
            result += car + space;
        }
        System.out.println(result);
    }

    /**
     * Récupère le nombre de wagons choisi par l'utilisateur
     *
     * @return le nombre de wagons
     */
    static int jeuTrain_saisirNombreWagon() {
        System.out.println("Combien de wagon faut-il ajouter ?");
        Scanner sc = new Scanner(System.in);
        int wagons = sc.nextInt();
        while (wagons == 0) {
            System.out.println("Combien de wagon faut-il ajouter ?");
            wagons = sc.nextInt();
        }
        return wagons;
    }

    /**
     * Affichage et vérification du jeu Train
     *
     * @param nbPassager le nombre d'usager
     * @return le nombre d'usager restant ou 0 ou -1
     */
    static boolean jeuTrain_afficheTrainCorrect(int nbPassager, int nbWagon) {
        int wagons_vide = nbWagon - nbPassager;// Nombre de wagons vides
        int passagerRestant = nbPassager - nbWagon;//Nombre d'usager restant
        boolean correct = false;
        //Si le joueur à juste
        if (nbPassager == nbWagon) {
            correct = true;
        }
        // Si pas il y a pas asser de wagons 
        if (nbPassager > nbWagon) {
            nbPassager = nbWagon;
        }
        jeuTrain_trainAffichage(nbPassager, nbWagon, wagons_vide);
        //Message si il reste des passages
        if (passagerRestant > 0) {
            System.out.println("Perdue !!! Il manque " + passagerRestant + " usager(s) à quai :");
            jeuTrain_afficherFormes(":)", passagerRestant);
            System.out.println("");
        }
        //Message si il y a trop de 
        if (nbPassager < nbWagon) {
            System.out.println("Perdue !!! Il y a trop de wagons");
        }
        return correct;
    }

    /**
     * Affiche le train en fonction du nombre de passagers et de wagons.
     *
     * @param nbPassager le passager à mettre dans le train
     * @param nbWagon le nombre wagon proposé par l'utilisateur
     * @param wagons_vide le nombre de trop sur le train
     */
    static void jeuTrain_trainAffichage(int nbPassager, int nbWagon, int wagons_vide) {
        //Si il y a trop de wagons
        if (nbPassager < nbWagon) {
            for (int i = 0; i < wagons_vide; i++) {
                System.out.println(""
                        + "  —————\n"
                        + "  |   |\n"
                        + "  |   |\n"
                        + "  |   |\n"
                        + "  —————\n"
                        + "    |  "
                );
            }
        }
        //Affichage dans tout les cas du jeu
        for (int i = 1; i <= nbPassager; i++) {
            System.out.println(""
                    + "  —————\n"
                    + "  |   |\n"
                    + "  | :)|\n"
                    + "  |   |\n"
                    + "  —————\n"
                    + "    |  "
            );
        }
        System.out.println("    |\n"
                + "   |||\n"
                + " .-----.\n"
                + " |o< >o|\n"
                + "//// \\\\\\\\\n"
                + "  /---\\ \n"
                + " /-----\\"
        );
    }

    /**
     * Affiche le train a l'envers en fonction du nombre de passagers et de
     * wagons.
     *
     * @param nbPassager le passager à mettre dans le train
     * @param nbWagon le nombre wagon proposé par l'utilisateur
     * @param wagons_vide le nombre de trop sur le train
     */
    static void jeuTrain_trainAffichage2(int nbPassager, int nbWagon, int wagons_vide) {

        System.out.println(""
                + " \\-----/\n"
                + "  \\---/ \n"
                + "\\\\\\\\ //// \n"
                + " |o< >o|\n"
                + " .-----.\n"
                + "   |||\n"
                + "    |"
        );
        //Affichage dans tout les cas du jeu
        for (int i = 1; i <= nbPassager; i++) {
            System.out.println(""
                    + "    |  \n"
                    + "  —————\n"
                    + "  |   |\n"
                    + "  | :)|\n"
                    + "  |   |\n"
                    + "  —————"
            );
        }
        //Si il y a trop de wagons
        if (nbPassager < nbWagon) {
            for (int i = 0; i < wagons_vide; i++) {
                System.out.println(""
                        + "    |  \n"
                        + "  —————\n"
                        + "  |   |\n"
                        + "  |   |\n"
                        + "  |   |\n"
                        + "  —————"
                );
            }
        }
    }

    ///////////////////////Jeu Course////////////////////////////
    /**
     * Lance une partie de Jeu de Course.
     *
     * @return si la partie est réussite
     */
    static boolean jeuCourse_principal() {
        jeuCourse_affichageRègles();
        Random random = new Random();
        int posJ1 = 1;
        int posJ2 = 1;
        int posJ3 = 1;
        int choixPion, nbCases;
        int joueurActif = 2;
        while (posJ1 < TAILLE_PLATEAU_COURSE - 1 && posJ2 < TAILLE_PLATEAU_COURSE - 1 && posJ3 < TAILLE_PLATEAU_COURSE - 1) {
            joueurActif = jeuCourse_joueurSuivant(joueurActif);
            if (joueurActif == 1) {
                choixPion = jeuCourse_choixPion(joueurActif);
                nbCases = jeuCourse_choixNbCases();
            } else {
                choixPion = jeuCourse_choixPionIA();
                System.out.println("De comb ien de cases voulez vous faire avancer le joueur ?");
                nbCases = random.nextInt(3) + 1;
                System.out.println(nbCases);
            }
            switch (choixPion) {
                case 1: {
                    posJ1 = jeuCourse_posJ1Correct(joueurActif, posJ1, posJ2, posJ3, nbCases);
                    break;
                }
                case 2: {
                    posJ2 = jeuCourse_posJ1Correct(joueurActif, posJ2,posJ1 , posJ3, nbCases);
                    break;
                }
                case 3: {
                    posJ3 = jeuCourse_posJ1Correct(joueurActif, posJ3, posJ2, posJ1, nbCases);
                    break;
                }
            }
            jeuCourse_afficheCourse(posJ1, posJ2, posJ3);
        }
        System.out.println("Le joueur " + joueurActif + " a gagnée !!!");
        return joueurActif == 1;
    }

    /**
     * Le choix de l'IA.(Random)
     *
     * @return un nombre aléatoire
     */
    static int jeuCourse_choixPionIA() {
        Random random = new Random();
        int choixPion = 0;
        System.out.println("L'IA joue \n");
        System.out.println("Quelle ligne voulez vous faire avancer ?");
        choixPion = random.nextInt(3) + 1;
        System.out.println(choixPion);
        return choixPion;
    }

    /**
     * Affichage des règles du Jeu de Course
     */
    static void jeuCourse_affichageRègles() {
        System.out.println("Jeu de Course\n");
        System.out.println("Ce jeu se joue à deux. Le premier qui fait passer la ligne d'arrivée à un joueur a gagnée\n"
                + "A chaque tour un seul poin se déplace de 1, 2 ou 3 cases.\n"
                + "Execpté au démarage, deux pions ne peuvent pas être positionnés au même endroit");
        jeuCourse_afficheCourse(0, 0, 0);
    }

    /**
     * Affiche le plateau de course
     *
     * @param posJ1 la position sur le plateau du 1er coureur
     * @param posJ2 la position sur le plateau du 2nd coureur
     * @param posJ3 la position sur le plateau du 3e coureur
     */
    static void jeuCourse_afficheCourse(int posJ1, int posJ2, int posJ3) {
        System.out.println(" - - - - - - - - - ARRIVEE");
        jeuCourse_afficheLigne('1', posJ1, TAILLE_PLATEAU_COURSE);
        jeuCourse_afficheLigne('2', posJ2, TAILLE_PLATEAU_COURSE);
        jeuCourse_afficheLigne('3', posJ3, TAILLE_PLATEAU_COURSE);
        System.out.println(" - - - - - - - - - ARRIVEE");
    }

    /**
     * Affiche une ligne du plateau de course
     *
     * @param car le symbole du représentatif du coureur
     * @param pos la position du coureur sur le plateau
     * @param taille la taille du plateau de course
     */
    static void jeuCourse_afficheLigne(char car, int pos, int taille) {
        String ligne = "";
        if (pos >= taille) {
            for (int i = 1; i < taille - 1; i++) {
                ligne = ligne + "| ";
            }
            ligne = ligne + "|" + car + "|";
        } else {
            for (int i = 1; i < pos; i++) {
                ligne = ligne + "| ";
            }
            ligne = ligne + "|" + car;
            for (int i = 1; i < taille - pos; i++) {
                ligne = ligne + "| ";
            }
            ligne = ligne + "|";
        }
        System.out.println(ligne);
    }

    /**
     * Change de joueur.
     *
     * @param joueurActif le joueur en jeu
     * @return le joueur suivant
     */
    static int jeuCourse_joueurSuivant(int joueurActif) {
        if (joueurActif == 1) {
            joueurActif = 2;
        } else {
            joueurActif = 1;
        }
        return joueurActif;
    }

    static int jeuCourse_choixPion(int joueurActif) {
        System.out.println("Joueur " + joueurActif + " joue\n");
        System.out.println("Quelle ligne voulez vous faire avancer ?");
        int choixPion = jeuAventure_saisirNombreIntervalle(1, 3);
        return choixPion;
    }

    static int jeuCourse_choixNbCases() {
        System.out.println("De combien de cases voulez vous faire avancer le joueur ?");
        int nbCases = jeuAventure_saisirNombreIntervalle(1, 3);
        return nbCases;
    }

    /**
     * Verifie si la psotion du pion 1 si elle n'est pas la même avec un autre.
     *
     * @param joueurActif le joueur
     * @param posJ1 position du pion 1
     * @param posJ2 position du pion 2
     * @param posJ3 position du pion 3
     * @param nbCases déplacement du pion
     * @return la position que le pion peut prendre dans le plateau
     */
    static int jeuCourse_posJ1Correct(int joueurActif, int posJ1, int posJ2, int posJ3, int nbCases) {
        Random random = new Random();
        if (joueurActif == 1) {
            while (posJ1 + nbCases == posJ2 || posJ1 + nbCases == posJ3) {
                System.out.println("De combien de cases voulez vous faire avancer le joueur ?");
                nbCases = jeuAventure_saisirNombreIntervalle(1, 3);
            }
        } else {
            while (posJ1 + nbCases == posJ2 || posJ1 + nbCases == posJ3) {
                System.out.println("De combien de cases voulez vous faire avancer le joueur ?");
                nbCases = random.nextInt(3) + 1;
            }
        }
        posJ1 = posJ1 + nbCases;
        return posJ1;
    }

    /**
     * Verifie si la psotion du pion 2 si elle n'est pas la même avec un autre.
     *
     * @param joueurActif le joueur
     * @param posJ1 position du pion 1
     * @param posJ2 position du pion 2
     * @param posJ3 position du pion 3
     * @param nbCases déplacement du pion
     * @return la position que le pion peut prendre dans le plateau
     */
    static int jeuCourse_posJ2Correct(int joueurActif, int posJ1, int posJ2, int posJ3, int nbCases) {
        Random random = new Random();
        if (joueurActif == 1) {
            while (posJ2 + nbCases == posJ1 || posJ2 + nbCases == posJ3) {
                System.out.println("De combien de cases voulez vous faire avancer le joueur ?");
                nbCases = jeuAventure_saisirNombreIntervalle(1, 3);
            }
        } else {
            while (posJ2 + nbCases == posJ1 || posJ2 + nbCases == posJ3) {
                System.out.println("De combien de cases voulez vous faire avancer le joueur ?");
                nbCases = random.nextInt(3) + 1;
            }
        }
        posJ2 = posJ2 + nbCases;
        return posJ2;
    }

    /**
     * Verifie si la psotion du pion 3 si elle n'est pas la même avec un autre.
     *
     * @param joueurActif le joueur
     * @param posJ1 position du pion 1
     * @param posJ2 position du pion 2
     * @param posJ3 position du pion 3
     * @param nbCases déplacement du pion
     * @return la position que le pion peut prendre dans le plateau
     */
    static int jeuCourse_posJ3Correct(int joueurActif, int posJ1, int posJ2, int posJ3, int nbCases) {
        Random random = new Random();
        if (joueurActif == 1) {
            while (posJ3 + nbCases == posJ1 || posJ3 + nbCases == posJ2) {
                System.out.println("De combien de cases voulez vous faire avancer le joueur ?");
                nbCases = jeuAventure_saisirNombreIntervalle(1, 3);
            }
        } else {
            while (posJ3 + nbCases == posJ1 || posJ3 + nbCases == posJ2) {
                System.out.println("De combien de cases voulez vous faire avancer le joueur ?");
                nbCases = random.nextInt(3) + 1;
            }
        }
        posJ3 = posJ3 + nbCases;
        return posJ3;
    }

    ////////////////////////Jeu Devin////////////////////////////////////////////////
    /**
     * Lance une partie de Jeu de Devin.
     *
     * @return si le jeu est réussi
     */
    static boolean jeuDevin_principal() {
        Random random = new Random();
        boolean jeuReussi = false;
        int nbCoups, limiteMax, reponse, nbChoisi, niveau;
        niveau = jeuAventure_saisirNiveauDifficulte();
        nbCoups = jeuDevin_nbCoup(niveau);
        limiteMax = jeuDevin_limite(niveau);
        reponse = random.nextInt(limiteMax - 0 + 1) + 0;
        do {
            System.out.println("Nombre d'esaie disponible : " + nbCoups);
            nbChoisi = jeuAventure_saisirNombreIntervalle(0, limiteMax);
            if (nbChoisi == reponse) {
                System.out.println("Bravo !!! Vous avez trouver la bonne réponse " + reponse);
                jeuReussi = true;
                break;
            }
            if (nbChoisi < reponse) {
                System.out.println("Le nombre est plus grand");
            } else {
                System.out.println("Le nombre est plus petit");
            }
            nbCoups--;
        } while (jeuReussi != true || reponse != nbChoisi || nbCoups != 0);
        return jeuReussi;
    }

    /**
     * Donne le nombre de tentatives possibles en fonction des niveau.
     *
     * @param niveau le niveau de difficulté du jeu Devin
     * @return le nombre de coups posibles
     */
    static int jeuDevin_nbCoup(int niveau) {
        int c = 0;
        switch (niveau) {
            case 1:
                c = 5;
                break;
            case 2:
            case 3:
                c = 10;
                break;
        }
        return c;
    }

    /**
     * Donne la limite max du nombre random à deviner selon le niveau de
     * difficulter.
     *
     * @param niveau le niveau de difficulté du jeu Devin
     * @return la limite du random du jeu Devin
     */
    static int jeuDevin_limite(int niveau) {
        int l = 0;
        switch (niveau) {
            case 1:
            case 2:
                l = 10;
                break;
            case 3:
                l = 100;
                break;
        }
        return l;
    }

/////////////////////////Fonction Jeu Aventure//////////////////////
    /**
     * Récupère un nombre d'une intervalle donnée.
     *
     * @return nombre saisie
     */
    static int jeuAventure_saisirNombreIntervalle(int min, int max) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Saisir une valeur entre " + min + " et " + max + " :");
        int num = sc.nextInt();
        while (!(num >= min && num <= max)) {
            System.out.println("Saisir une valeur entre " + min + " et " + max + " :");
            num = sc.nextInt();
        }
        return num;
    }

    /**
     * Récupère le niveau de difficulté.
     *
     * @return le niveau
     */
    static int jeuAventure_saisirNiveauDifficulte() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Saisir un niveau de difficulter entre " + DIFFICULTE_MIN + " et " + DIFFICULTE_MAX);
        int num = sc.nextInt();
        System.out.println("");
        System.out.println("Niveau " + num + " :");
        while (!(num >= DIFFICULTE_MIN && num <= DIFFICULTE_MAX)) {
            System.out.println("Saisir un niveau de difficulter entre " + DIFFICULTE_MIN + " et " + DIFFICULTE_MAX);
            num = sc.nextInt();
            System.out.println("");
            System.out.println("Niveau " + num + " :");
        }
        return num;
    }

///////////////////////////////////////////////////////////////////////////////
/*Affichage Graphique*/
    /**
     * Affichage du menu
     *
     */
    static void afficheMenu() {
        System.out.println("           \\\\\\||||||////\n"
                + "            \\\\  ~ ~  //\n"
                + "             (  @ @  )\n"
                + "    ______ oOOo-(_)-oOOo___________\n"
                + "\n"
                + "\t (1) trouver la suite " + "\n"
                + "\t (2) jeu du train " + "\n"
                + "\t (3) course en ligne " + "\n"
                + "\t (4) le devin " + "\n"
                + "\t (5) quitter " + "\n"
                + "\n"
                + "    _____________Oooo._____________\n"
                + "       .oooO     (   )\n"
                + "        (   )     ) /\n"
                + "         \\ (     (_/\n"
                + "          \\_)");
    }

    /**
     * Affichage de la fin du jeu.
     */
    static void afficherFinJeu(int nbParties, int partiesGagnée) {
        System.out.println("   .____________________.\n"
                + "   |.------------------.|\n"
                + "   ||                  ||\n"
                + "   ||    GAME OVER     ||\n"
                + "   ||Parties jouées: " + nbParties + " ||\n"
                + "   ||                  ||\n"
                + "   ||Parties gagnées: " + partiesGagnée + "||\n"
                + "   ||__________________||\n"
                + "   /.-.-.-.-.-.-.-.-.-.-\\\n"
                + "  /.-.-.-.-.-.-.-.-.-.-.-\\\n"
                + " /.-.-.-.-.-.-.-.-.-.-.-.-\\\n"
                + "/______/__________\\___o____\\    \n"
                + "\\__________________________"
                + "/");
    }

}
