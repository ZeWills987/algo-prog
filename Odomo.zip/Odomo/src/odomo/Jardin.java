package odomo;

/**
 * Gestion de la partie Jardin.
 */
class Jardin {
    
}
