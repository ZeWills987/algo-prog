package morpion;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

/**
 *
 */
public class CoordonneesTest {

    @Test
    public void testEstDansPlateau() {
        assertTrue(Coordonnees.estDansPlateau(new Coordonnees(0, 0), 14));
        assertTrue(Coordonnees.estDansPlateau(new Coordonnees(13, 13), 14));
        assertTrue(Coordonnees.estDansPlateau(new Coordonnees(0, 1), 14));
        assertFalse(Coordonnees.estDansPlateau(new Coordonnees(-1, 1), 14));
        assertTrue(Coordonnees.estDansPlateau(new Coordonnees(7, 13), 14));
        assertFalse(Coordonnees.estDansPlateau(new Coordonnees(7, 14), 14));
        assertTrue(Coordonnees.estDansPlateau(new Coordonnees(13, 0), 14));
        assertFalse(Coordonnees.estDansPlateau(new Coordonnees(14, 0), 14));
        assertTrue(Coordonnees.estDansPlateau(new Coordonnees(7, 0), 14));
        assertFalse(Coordonnees.estDansPlateau(new Coordonnees(7, -1), 14));
        assertTrue(Coordonnees.estDansPlateau(new Coordonnees(0, 1), 2));
        assertFalse(Coordonnees.estDansPlateau(new Coordonnees(0, 1), 1));
    }

    @Test
    public void testSuivante() {
        assertEquals(new Coordonnees(5, 4),
                Coordonnees.suivante(new Coordonnees(4, 4), Direction.SUD));
        assertEquals(new Coordonnees(0, 0),
                Coordonnees.suivante(new Coordonnees(1, 1), Direction.NORD_OUEST));
        assertEquals(new Coordonnees(-1, -1),
                Coordonnees.suivante(new Coordonnees(0, 0), Direction.NORD_OUEST));
        assertEquals(new Coordonnees(199, 201),
                Coordonnees.suivante(new Coordonnees(200, 200), Direction.NORD_EST));
    }

    @Test
    public void testVoisines() {
        int taille = 10;
        // points au 4 côtés 
        Coordonnees point1 = new Coordonnees(0, 0);
        assertEquals(Coordonnees.voisines(point1, taille), 3);
        Coordonnees point2 = new Coordonnees(0, 9);
        assertEquals(Coordonnees.voisines(point2, taille), 3);
        Coordonnees point3 = new Coordonnees(9, 0);
        assertEquals(Coordonnees.voisines(point3, taille), 3);
        Coordonnees point4 = new Coordonnees(9, 9);
        assertEquals(Coordonnees.voisines(point4, taille), 3);
        // point au bord et loins des côtes
        Coordonnees point5 = new Coordonnees(4, 0);
        assertEquals(Coordonnees.voisines(point5, taille),5);
        // point loins des bords et des côtes 
        Coordonnees point6 = new Coordonnees(4,4);
        assertEquals(Coordonnees.voisines(point6,taille),8);
    }
}
