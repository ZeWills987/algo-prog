/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package cycle2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author William Tchang
 */
public class EspaceEtudiantIT {
    


    /**
     * Test of etu_remplissageTableaux method, of class EspaceEtudiant.
     */
    @Test
    public void testRemplissageTableaux() {
        System.out.println("remplissageTableaux");
        EspaceEtudiant.etu_remplissageTableaux();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of remplirTableauAléatoire method, of class EspaceEtudiant.
     */
    @Test
    public void testRemplirTableauAléatoire() {
        System.out.println("remplirTableauAl\u00e9atoire");
        int[] tab = null;
        int expResult = 0;
        int result = EspaceEtudiant.remplirTableauAléatoire(tab);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }



    /**
     * Test de la méthode moyenneUE, de la classe EspaceEtudiant.
     */
    @Test
    public void testMoyenneUE() {
        System.out.println("moyenneUE");
        int[] tab = {10,10,10,10};
        int tailleTab = 4;
        double expResult = 10.0;
        double result = EspaceEtudiant.moyenneUE(tab, tailleTab);
        assertEquals(expResult, result, 0.0);
        int tab1[] = {0,10,18,9,5};
        assertEquals(8.4, EspaceEtudiant.moyenneUE(tab1, 5), 0.9);
    }

    /**
     * Test de la méthode noteMin, de la classe EspaceEtudiant.
     */
    @Test
    public void testNoteMin() {
        System.out.println("noteMin");
        int[] tab = {20,0};
        int tailleTab = 2;
        int expResult = 0;
        int result = EspaceEtudiant.noteMin(tab, tailleTab);
        assertEquals(expResult, result);
        int tab1[] = {10,5,20,4,9};
        assertEquals(4,EspaceEtudiant.noteMin(tab1, 5) );
    }

    /**
     * Test de la méthode noteMax, de la classe EspaceEtudiant.
     */
    @Test
    public void testNoteMax() {
        System.out.println("noteMax");
        int[] tab = {9,1,10,20,5,8};
        int tailleTab = 6;
        int expResult = 20;
        int result = EspaceEtudiant.noteMax(tab, tailleTab);
        assertEquals(expResult, result);
    }

    /**
     * Test of devin_noteUE_Semestre method, of class EspaceEtudiant.
     */
    @Test
    public void testDevin_noteUE_Semestre() {
        System.out.println("devin_noteUE_Semestre");
        int[] tab = null;
        int taille = 0;
        EspaceEtudiant.devin_noteUE_Semestre(tab, taille);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of etu_annéeValidé method, of class EspaceEtudiant.
     */
    @Test
    public void testEtu_annéeValidé() {
        System.out.println("etu_ann\u00e9eValid\u00e9");
        EspaceEtudiant.etu_annéeValidé();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of semestreValidé method, of class EspaceEtudiant.
     */
    @Test
    public void testSemestreValidé() {
        System.out.println("semestreValid\u00e9");
        boolean expResult = false;
        boolean result = EspaceEtudiant.semestreValidé();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of validéUE method, of class EspaceEtudiant.
     */
    @Test
    public void testValidéUE() {
        System.out.println("valid\u00e9UE");
        double moyS1 = 0.0;
        double moyS2 = 0.0;
        boolean expResult = false;
        boolean result = EspaceEtudiant.validéUE(moyS1, moyS2);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
