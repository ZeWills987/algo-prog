/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cycle2;

import static cycle2.Cycle2.TAILLE_TAB;
import static cycle2.Cycle2.saisirNombreIntervalle;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author William Tchang
 */
public class EspaceDDE {

    static final int NB_UE = 3;
    static final int NB_ETU = 5;
    static double[][] tab_moy = new double[NB_UE][NB_ETU];
    static boolean[][] tab_abs = new boolean[NB_UE][NB_ETU];

    /**
     *
     * @param tab
     */
    static void dde_remplissageTabAléatoire(double[][] tab) {
        Random random = new Random();
        int min = 0;
        int max = 20;
        for (int i = 0; i < tab.length; i++) {
            for (int y = 0; y < tab[0].length; y++) {
                tab[i][y] = random.nextDouble() * (max - min) + min;
            }
        }
    }

    /**
     * Remplisssage des tableaux de moyennes et d'absences
     */
    static void dde_remplissageTableaux() {
        dde_remplissageTabAléatoire(tab_moy);
        tab_abs[0][0] = false;//etu 1
        tab_abs[0][1] = true;//etu 2
        tab_abs[0][2] = true;//etu 3
        tab_abs[0][3] = false;//etu 4
        tab_abs[0][4] = false;//etu 5

        tab_abs[1][0] = true;//etu 1
        tab_abs[1][1] = true;//etu 2
        tab_abs[1][2] = false;//etu 3
        tab_abs[1][3] = false;//etu 4
        tab_abs[1][4] = false;//etu 5

        tab_abs[2][0] = true;//etu 1
        tab_abs[2][1] = true;//etu 2
        tab_abs[2][2] = true;//etu 3
        tab_abs[2][3] = true;//etu 4
        tab_abs[2][4] = false;//etu 5
    }

    /**
     * Calcule la moyenne d'une UE (une colonne du tableau 2D).
     *
     * @param tab le tableau de moyenne
     * @param UE l'UE choisie
     * @return la moyenne de l'UE choisie
     */
    static double dde_moyenneUE(double[][] tab, int UE) {
        double somme = 0;
        for (int i = 0; i < tab[UE].length; i++) {
            somme += tab[UE][i];
        }
        return somme / (tab[UE].length - 1);
    }

    /**
     * Converti un boolean en symbole selon leurs valeur de vériter.
     *
     * @param présent si l'étudiant a été prensent
     * @return le symbole associé à la valeur de vérité
     */
    static String dde_booleanToSrting(boolean présent) {
        String symbole;
        if (!présent) {
            symbole = "X";
        } else {
            symbole = "0";
        }
        return symbole;
    }

    /**
     * Affichage des notes de cahque étudiants.
     */
    static void dde_note_etu() {
        System.out.println("************************ NOTES DES ETUDIANTS ************************");
        //Etu 1
        System.out.printf("Etudiant numéro 1       UE_1 : %.2f       UE_2 : %.2f    UE_3 : %.2f\n",
                tab_moy[0][0], tab_moy[1][0], tab_moy[2][0]);
        //Etu 2
        System.out.printf("Etudiant numéro 2       UE_1 : %.2f       UE_2 : %.2f    UE_3 : %.2f\n",
                tab_moy[0][1], tab_moy[1][1], tab_moy[2][1]);
        //Etu 3
        System.out.printf("Etudiant numéro 3       UE_1 : %.2f       UE_2 : %.2f    UE_3 : %.2f\n",
                tab_moy[0][2], tab_moy[1][2], tab_moy[2][2]);
        //Etu 4
        System.out.printf("Etudiant numéro 4       UE_1 : %.2f       UE_2 : %.2f    UE_3 : %.2f\n",
                tab_moy[0][3], tab_moy[1][3], tab_moy[2][3]);
        //Etu 5
        System.out.printf("Etudiant numéro 5       UE_1 : %.2f       UE_2 : %.2f    UE_3 : %.2f\n" + "\n",
                tab_moy[0][4], tab_moy[1][4], tab_moy[2][4]);
    }

    static void dde_absences_etu() {
        System.out.println("************************ ABSENCES DES ETUDIANTS ************************\n"
                + "Etudiant numéro 1       UE_1 : " + dde_booleanToSrting(tab_abs[0][0]) + "       "
                + "UE_2 : " + dde_booleanToSrting(tab_abs[1][0]) + "    UE_3 : " + dde_booleanToSrting(tab_abs[2][0]) + "\n"
                + "Etudiant numéro 2       UE_1 : " + dde_booleanToSrting(tab_abs[0][1]) + "       "
                + "UE_2 : " + dde_booleanToSrting(tab_abs[1][1]) + "    UE_3 : " + dde_booleanToSrting(tab_abs[2][1]) + "\n"
                + "Etudiant numéro 3       UE_1 : " + dde_booleanToSrting(tab_abs[0][2]) + "       "
                + "UE_2 : " + dde_booleanToSrting(tab_abs[1][2]) + "    UE_3 : " + dde_booleanToSrting(tab_abs[2][2]) + "\n"
                + "Etudiant numéro 4       UE_1 : " + dde_booleanToSrting(tab_abs[0][3]) + "       "
                + "UE_2 : " + dde_booleanToSrting(tab_abs[1][3]) + "    UE_3 : " + dde_booleanToSrting(tab_abs[2][3]) + "\n"
                + "Etudiant numéro 5       UE_1 : " + dde_booleanToSrting(tab_abs[0][4]) + "       "
                + "UE_2 : " + dde_booleanToSrting(tab_abs[1][4]) + "    UE_3 : " + dde_booleanToSrting(tab_abs[2][4]) + "\n"
                + "\n"
                + "************************ MOYENNES DES UE ************************");
    }

    /**
     * Affiche la moyenne générale de chauqe UE.
     */
    static void dde_moyenne_UE() {
        int UE1 = 0;
        int UE2 = 1;
        int UE3 = 2;
        System.out.printf("moyenne de l'UE 1: %.2f\n", dde_moyenneUE(tab_moy, UE1));
        System.out.printf("moyenne de l'UE 2: %.2f\n", dde_moyenneUE(tab_moy, UE2));
        System.out.printf("moyenne de l'UE 3: %.2f\n" + "\n", dde_moyenneUE(tab_moy, UE3));
    }

    /**
     * Affichage des informations générales concernant tout les étudiants.
     */
    static void dde_information_générale() {
        dde_note_etu();
        dde_absences_etu();
        dde_moyenne_UE();
    }

/////////////////////////// Fonctionalité 2 : modification d'une moyenne //////////////////////////////////////
    /**
     * Donne la moyenne maximal d'un étudiant.
     *
     * @param tab le tableau de moyenne
     * @param etu le numéro de l'étudiant
     * @return la moyenne max
     */
    static double dde_moyenne_max(double[][] tab, int etu) {
        double max = 0.;
        for (int i = 0; i < tab_moy.length; i++) {
            if (max < tab[i][etu]) {
                max = tab_moy[i][etu];
            }
        }
        return max;
    }

    /**
     * Modifie la moyenne d'un étudiant selon des critères précises.
     */
    static void dde_modification_moyenne() {
        int numEtu, numUE;
        double note;
        System.out.println("Chosir un étudiant [1-5] :");
        numEtu = saisirNombreIntervalle(1, 5);
        int indiceEtu = numEtu - 1;
        System.out.println("Chosir l'UE [1-3] :");
        numUE = saisirNombreIntervalle(1, 3);
        int indiceUE = numUE - 1;
        System.out.println("Saisir la nouvelle note de l'étudiant :");
        note = saisirNombreIntervalle(0, 20);
        if (note > tab_moy[indiceEtu][indiceUE]) {
            if (note > dde_moyenne_max(tab_moy, indiceEtu)) {
                tab_moy[indiceEtu][indiceUE] = dde_moyenne_max(tab_moy, indiceEtu);
                System.out.println("La note à été modifiée au max de la note de l'étudiant");
            }else{
                tab_moy[indiceEtu][indiceUE] = note;
                System.out.println("La note a été modifiée");
            }
        }else{
            System.out.println("La note n'a pas été modifiée");
        }
    }

    ///////////////////////// Fonctionalité 3 : /////////////////////// 
}
