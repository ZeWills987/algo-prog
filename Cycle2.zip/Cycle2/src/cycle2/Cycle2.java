/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cycle2;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author William Tchang
 */
public class Cycle2 {

    static final int TAILLE_TAB = 10;
    static int[] tab_U1S1 = new int[TAILLE_TAB];
    static int[] tab_U2S1 = new int[TAILLE_TAB];
    static int[] tab_U3S1 = new int[TAILLE_TAB];
    static int[] tab_U1S2 = new int[TAILLE_TAB];
    static int[] tab_U2S2 = new int[TAILLE_TAB];
    static int[] tab_U3S2 = new int[TAILLE_TAB];

    static int taille_tabU1S1 = 0;
    static int taille_tabU2S1 = 0;
    static int taille_tabU3S1 = 0;
    static int taille_tabU1S2 = 0;
    static int taille_tabU2S2 = 0;
    static int taille_tabU3S2 = 0;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        menu_principal();
    }

    /**
     * Menu principal permettant l'appel des différents fonctionalités du
     * logiciel.
     */
    static void menu_principal() {
        boolean terminé = false;
        int choix;
        while (!terminé) {
            affiche_menu();
            choix = saisirNombreIntervalle(1, 5);
            switch (choix) {
                case 1 -> {
                    afficherNotesUE();
                }
                case 2 -> {
                    //afficherStat();
                }
                case 3 -> {
                    //
                }
                case 4 -> {
                    //notePrévisionel();
                }
                case 5 -> {
                    terminé = true;
                }
                default -> {
                    messageErreur();
                    terminé = true;
                }
            }
        }
    }
    
    static void afficherNotesUE(){
        int choix_UE,choix_semestre; 
        System.out.println("Quelle UE ? 1/2/3");
        choix_UE = saisirNombreIntervalle(1,3);
        System.out.println("Quelle semestre ? 1/2");
        choix_semestre = saisirNombreIntervalle(1,2);
        /*for (int i = 0; i<,i++){
            
        }*/
    }
    
    /**
     * 
     */
    static void remplissageTableaux(){
        int[][] tableauNotesUE;
        taille_tabU1S1 = remplirTableauAléatoire(tab_U1S1);
        taille_tabU2S1 = remplirTableauAléatoire(tab_U2S1);
        taille_tabU3S1 = remplirTableauAléatoire(tab_U3S1);
        taille_tabU1S2 = remplirTableauAléatoire(tab_U1S2);
        taille_tabU2S2 = remplirTableauAléatoire(tab_U2S2);
        taille_tabU3S2 = remplirTableauAléatoire(tab_U3S2);
        
        for (int i = 0;>){
            
        }
        
    }
    
    /**
     * Remplissage aléatoire d'un tableau rempli en paramètre.
     *
     * @param tab tableau d'entier
     * @return le nombre de notes entré dans le tableau
     */
    static int remplirTableauAléatoire(int[] tab) {
        Random random = new Random();
        int nombreNotes = random.nextInt(1, TAILLE_TAB);
        for (int i = 0; i < nombreNotes - 1; i++) {
            tab[i] = random.nextInt(0,20);
        }
        return nombreNotes;
    }

    /**
     * Message en cas d'erreur.
     */
    static void messageErreur() {
        System.out.println("Erreur 404. Fermeture forcé du logiciel !!!");
    }

    /**
     * Récupère un nombre d'une intervalle donnée.
     *
     * @return nombre saisie
     */
    static int saisirNombreIntervalle(int min, int max) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Saisir une valeur entre " + min + " et " + max + " :");
        int num = sc.nextInt();
        while (!(num >= min && num <= max)) {
            System.out.println("Saisir une valeur entre " + min + " et " + max + " :");
            num = sc.nextInt();
        }
        return num;
    }

    /**
     *Affichage du menu de démarage.
     */
    static void affiche_menu() {
        System.out.println("(1) afficher notes d'une UE\n"
                + "(2) statistiques de vos UE\n"
                + "(3) Note à obtenir au prochain devoir d'une UE pour avoir la moyenne\n"
                + "(4) UE validées sur l'année\n"
                + "(5) quitter");
    }
}
