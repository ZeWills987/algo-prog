/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cycle2;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author William Tchang
 */
public class Cycle2 {

    static final int TAILLE_TAB = 10;
    static int[] tab_U1S1 = new int[TAILLE_TAB];
    static int[] tab_U2S1 = new int[TAILLE_TAB];
    static int[] tab_U3S1 = new int[TAILLE_TAB];
    static int[] tab_U1S2 = new int[TAILLE_TAB];
    static int[] tab_U2S2 = new int[TAILLE_TAB];
    static int[] tab_U3S2 = new int[TAILLE_TAB];

    static int taille_tabU1S1 = 0;
    static int taille_tabU2S1 = 0;
    static int taille_tabU3S1 = 0;
    static int taille_tabU1S2 = 0;
    static int taille_tabU2S2 = 0;
    static int taille_tabU3S2 = 0;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        remplissageTableaux();
        menu_principal();
    }

    /**
     * Menu principal permettant l'appel des différents fonctionalités du
     * logiciel.
     */
    static void menu_principal() {
        boolean terminé = false;
        int choix;
        while (!terminé) {
            affiche_menu();
            choix = saisirNombreIntervalle(1, 5);
            switch (choix) {
                case 1: {
                    afficherNotesUE();
                    break;
                }
                case 2: {
                    //afficherStat();
                    break;
                }
                case 3 : {
                    //
                    break;
                }
                case 4 : {
                    //notePrévisionel();
                    break;
                }
                case 5 : {
                    terminé = true;
                    break;
                }
                default : {
                    messageErreur();
                    terminé = true;
                    break;
                }
            }
        }
    }
    
    static void afficherStat(){
        
    }

    static void afficherNotesUE() {
        int choix_UE, choix_semestre;
        String str = "";
        System.out.println("Quelle UE ? 1/2/3");
        choix_UE = saisirNombreIntervalle(1, 3);
        System.out.println("Quelle semestre ? 1/2");
        choix_semestre = saisirNombreIntervalle(1, 2);
        switch (choix_UE) {
            case 1:
                switch (choix_semestre) {
                    case 1:
                        str = stringUeSemestre(tab_U1S1, taille_tabU1S1);
                        break;
                    case 2:
                        str = stringUeSemestre(tab_U1S2, taille_tabU1S2);
                        break;
                }
                break;
            case 2:
                switch (choix_semestre) {
                    case 1:
                        str = stringUeSemestre(tab_U2S1, taille_tabU2S1);
                        break;
                    case 2:
                        str = stringUeSemestre(tab_U2S2, taille_tabU2S2);
                        break;
                }
                break;
            case 3:
                switch (choix_semestre) {
                    case 1:
                        str = stringUeSemestre(tab_U3S1, taille_tabU3S1);
                        break;
                    case 2:
                        str = stringUeSemestre(tab_U3S2, taille_tabU3S2);
                        break;
                }
                break;
        }
        System.out.println("Notes de l'UE" + choix_UE + " semestre " + choix_semestre + " : " + str);
        System.out.println("");
    }
    
    /**
     * Donne la moyenne d'une UE
     * 
     * @param tab
     * @param tailleTab
     * @return 
     */
    static int moyenneUE(int[] tab, int tailleTab){
        int moy=0;
        for (int i = 0; i < tailleTab;i++){
            moy = moy + tab[i];
        }
        moy= moy/tailleTab;
        return moy;
    }
    
    /**
     * Donne la note minimal d'un UE.
     * 
     * @param tab
     * @param tailleTab
     * @return 
     */
    static int noteMin(int[] tab,int tailleTab){
        int min = tab[0];
        for (int i = 0;i<tailleTab;i++){
            if(min < tab[i]){
                min = tab[i];
            }
        }
        return min;
    }
    
    /**
     *
     * @param tab
     * @param tailleTab
     * @return
     */
    static String stringUeSemestre(int[] tab, int tailleTab) {
        String str = "";
        for (int i = 0; i < tailleTab; i++) {
            str = str + Integer.toString(tab[i]) + "/20 ";
        }
        return str;
    }

    /**
     *
     */
    static void remplissageTableaux() {
        taille_tabU1S1 = remplirTableauAléatoire(tab_U1S1);
        taille_tabU2S1 = remplirTableauAléatoire(tab_U2S1);
        taille_tabU3S1 = remplirTableauAléatoire(tab_U3S1);
        taille_tabU1S2 = remplirTableauAléatoire(tab_U1S2);
        taille_tabU2S2 = remplirTableauAléatoire(tab_U2S2);
        taille_tabU3S2 = remplirTableauAléatoire(tab_U3S2);
    }

    /**
     * Remplissage aléatoire d'un tableau rempli en paramètre.
     *
     * @param tab tableau d'entier
     * @return le nombre de notes entré dans le tableau
     */
    static int remplirTableauAléatoire(int[] tab) {
        Random random = new Random();
        int nombreNotes;
        nombreNotes = random.nextInt(TAILLE_TAB - 1 + 1) + 1;
        for (int i = 0; i < nombreNotes - 1; i++) {
            tab[i] = random.nextInt(20 - 0 + 1) + 0;
        }
        return nombreNotes;
    }

    /**
     * Message en cas d'erreur.
     */
    static void messageErreur() {
        System.out.println("Erreur 404. Fermeture forcé du logiciel !!!");
    }

    /**
     * Récupère un nombre d'une intervalle donnée.
     *
     * @return nombre saisie
     */
    static int saisirNombreIntervalle(int min, int max) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Saisir une valeur entre " + min + " et " + max + " :");
        int num = sc.nextInt();
        while (!(num >= min && num <= max)) {
            System.out.println("Saisir une valeur entre " + min + " et " + max + " :");
            num = sc.nextInt();
        }
        return num;
    }

    /**
     * Affichage du menu de démarage.
     */
    static void affiche_menu() {
        System.out.println("(1) afficher notes d'une UE\n"
                + "(2) statistiques de vos UE\n"
                + "(3) Note à obtenir au prochain devoir d'une UE pour avoir la moyenne\n"
                + "(4) UE validées sur l'année\n"
                + "(5) quitter");
    }
}
