/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cycle2;

import static cycle2.EspaceDDE.dde_information_générale;
import static cycle2.EspaceDDE.dde_remplissageTableaux;
import static cycle2.EspaceDDE.tab_abs;
import static cycle2.EspaceDDE.tab_moy;
import static cycle2.EspaceEtudiant.etu_affiche_menu;
import static cycle2.EspaceEtudiant.etu_afficherInfosDesUE;
import static cycle2.EspaceEtudiant.etu_afficherNotesUE;
import static cycle2.EspaceEtudiant.etu_annéeValidé;
import static cycle2.EspaceEtudiant.etu_noteAObtenir;
import java.util.Scanner;
import static cycle2.EspaceEtudiant.etu_remplissageTableaux;

/**
 *
 * @author William Tchang
 */
public class Cycle2 {

    ////////////Notes par UE et par Semestre/////////////////
    static final int TAILLE_TAB = 10;
    static int[] tab_U1S1 = new int[TAILLE_TAB];
    static int[] tab_U2S1 = new int[TAILLE_TAB];
    static int[] tab_U3S1 = new int[TAILLE_TAB];
    static int[] tab_U1S2 = new int[TAILLE_TAB];
    static int[] tab_U2S2 = new int[TAILLE_TAB];
    static int[] tab_U3S2 = new int[TAILLE_TAB];

    ////////Nombre de note par UE et par Semestre//////
    static int taille_tabU1S1 = 0;
    static int taille_tabU2S1 = 0;
    static int taille_tabU3S1 = 0;
    static int taille_tabU1S2 = 0;
    static int taille_tabU2S2 = 0;
    static int taille_tabU3S2 = 0;

    /////////Moyenne par UE et Semestre////////////////
    static double moyU1S1;
    static double moyU2S1;
    static double moyU3S1;
    static double moyU1S2;
    static double moyU2S2;
    static double moyU3S2;

    /////////Moyenne Générale de lannée//////////////////
    static double moyenneGen;

    /////////Notes minimal par UE et par Semestre////////
    static int minU1S1;
    static int minU2S1;
    static int minU3S1;
    static int minU1S2;
    static int minU2S2;
    static int minU3S2;

    /////////Notes maximal par UE et par Semestre////////
    static int maxU1S1;
    static int maxU2S1;
    static int maxU3S1;
    static int maxU1S2;
    static int maxU2S2;
    static int maxU3S2;
    public static Object EpsaceEtudiant;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        etu_remplissageTableaux();
        dde_remplissageTableaux();
        menu_principal();
    }

    /**
     * Menu principal permettant l'appel des différents fonctionalités du
     * logiciel.
     */
    static void menu_principal() {
        boolean terminé = false;
        int choix;
        while (!terminé) {
            System.out.println("Saisir si 1) vous êtes étudiant, saisir 2) si vous de la DDE");
            choix = saisirNombreIntervalle(1, 2);
            if (choix == 1) {
                // Gestion de l'espace étudiant
                etu_affiche_menu();
                choix = saisirNombreIntervalle(1, 5);
                switch (choix) {
                    case 1: {
                        etu_afficherNotesUE();
                        break;
                    }
                    case 2: {
                        etu_afficherInfosDesUE();
                        break;
                    }
                    case 3: {
                        etu_noteAObtenir();
                        break;
                    }
                    case 4: {
                        etu_annéeValidé();
                        break;
                    }
                    case 5: {
                        terminé = true;
                        break;
                    }
                    default: {
                        messageErreur();
                        terminé = true;
                        break;
                    }
                }
            } else {
                //Gestion de l'epace DDE
                dde_affiche_menu();
                choix = saisirNombreIntervalle(1, 4);
                switch (choix) {
                    case 1: {
                        dde_information_générale();
                        break;
                    }
                    case 2: {
                        //dde_modification_moyenne();
                        break;
                    }
                    case 3: {
                        //dde_listing_rattrapages;
                        break;
                    }
                    case 4: {
                        terminé = true;
                        break;
                    }
                    default: {
                        messageErreur();
                        terminé = true;
                        break;
                    }
                }
            }
        }
    }

    /**
     * Récupère un nombre d'une intervalle donnée.
     *
     * @return nombre saisie
     */
    static int saisirNombreIntervalle(int min, int max) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Saisir une valeur entre " + min + " et " + max + " :");
        int num = sc.nextInt();
        while (!(num >= min && num <= max)) {
            System.out.println("Saisir une valeur entre " + min + " et " + max + " :");
            num = sc.nextInt();
        }
        return num;
    }

    /**
     * Message en cas d'erreur.
     */
    static void messageErreur() {
        System.out.println("Erreur 404. Fermeture forcé du logiciel !!!");
    }

///////////////////////////////////////////// Partie 2 : Espace DDE //////////////////////////////////////
    /**
     * Affiche du menu de l'espace DDE.
     */
    static void dde_affiche_menu() {
        System.out.println("(1) Information générale sur les notes et absences UE\n"
                + "(2) Modification d'une moyenne\n"
                + "(3) Listng des rattrapages à organiser\n"
                + "(4) Quitter\n");
    }    
}
