/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cycle2;

import static cycle2.Cycle2.TAILLE_TAB;
import static cycle2.Cycle2.maxU1S1;
import static cycle2.Cycle2.maxU1S2;
import static cycle2.Cycle2.maxU2S1;
import static cycle2.Cycle2.maxU2S2;
import static cycle2.Cycle2.maxU3S1;
import static cycle2.Cycle2.maxU3S2;
import static cycle2.Cycle2.minU1S1;
import static cycle2.Cycle2.minU1S2;
import static cycle2.Cycle2.minU2S1;
import static cycle2.Cycle2.minU2S2;
import static cycle2.Cycle2.minU3S1;
import static cycle2.Cycle2.minU3S2;
import static cycle2.Cycle2.moyU1S1;
import static cycle2.Cycle2.moyU1S2;
import static cycle2.Cycle2.moyU2S1;
import static cycle2.Cycle2.moyU2S2;
import static cycle2.Cycle2.moyU3S1;
import static cycle2.Cycle2.moyU3S2;
import static cycle2.Cycle2.moyenneGen;
import static cycle2.Cycle2.saisirNombreIntervalle;
import static cycle2.Cycle2.tab_U1S1;
import static cycle2.Cycle2.tab_U1S2;
import static cycle2.Cycle2.tab_U2S1;
import static cycle2.Cycle2.tab_U2S2;
import static cycle2.Cycle2.tab_U3S1;
import static cycle2.Cycle2.tab_U3S2;
import static cycle2.Cycle2.taille_tabU1S1;
import static cycle2.Cycle2.taille_tabU1S2;
import static cycle2.Cycle2.taille_tabU2S1;
import static cycle2.Cycle2.taille_tabU2S2;
import static cycle2.Cycle2.taille_tabU3S1;
import static cycle2.Cycle2.taille_tabU3S2;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author William Tchang
 */
public class EspaceEtudiant {
    ///////////////////////////////// Partie 1 : Espace étudiant ////////////////////////////
    /**
     * Affichage du menu de démarage.
     */
    static void etu_affiche_menu() {
        System.out.println("(1) afficher notes d'une UE\n"
                + "(2) statistiques de vos UE\n"
                + "(3) Note à obtenir au prochain devoir d'une UE pour avoir la moyenne\n"
                + "(4) UE validées sur l'année\n"
                + "(5) quitter");
    }

////////////////////////// Fonctionalité 1 : Affichage les notes d'une UE pour un semestre ///////////////
    /**
     * Afiichage des notes d'une UE pour un semestre.
     *
     */
    static void etu_afficherNotesUE() {
        int choix_UE, choix_semestre;
        String str = "";
        System.out.println("Quelle UE ? 1/2/3");
        choix_UE = saisirNombreIntervalle(1, 3);
        System.out.println("Quelle semestre ? 1/2");
        choix_semestre = saisirNombreIntervalle(1, 2);
        switch (choix_UE) {
            case 1:
                switch (choix_semestre) {
                    case 1:
                        str = stringUeSemestre(tab_U1S1, taille_tabU1S1);
                        break;
                    case 2:
                        str = stringUeSemestre(tab_U1S2, taille_tabU1S2);
                        break;
                }
                break;
            case 2:
                switch (choix_semestre) {
                    case 1:
                        str = stringUeSemestre(tab_U2S1, taille_tabU2S1);
                        break;
                    case 2:
                        str = stringUeSemestre(tab_U2S2, taille_tabU2S2);
                        break;
                }
                break;
            case 3:
                switch (choix_semestre) {
                    case 1:
                        str = stringUeSemestre(tab_U3S1, taille_tabU3S1);
                        break;
                    case 2:
                        str = stringUeSemestre(tab_U3S2, taille_tabU3S2);
                        break;
                }
                break;
        }
        System.out.println("Notes de l'UE" + choix_UE + " semestre " + choix_semestre + " : " + str);
        System.out.println("");
    }

    /**
     * Gère l'affiche d'une UE.
     *
     * @param tab les notes d'une UE
     * @param tailleTab le nombre de notes
     * @return les notes de l'UE en question dans la console
     */
    static String stringUeSemestre(int[] tab, int tailleTab) {
        String str = "";
        for (int i = 0; i < tailleTab; i++) {
            str = str + Integer.toString(tab[i]) + "/20 ";
        }
        return str;
    }

    /**
     * Remplis mes tableau avec des notes et recupère le nombre de notes les
     * moyennes, les notes minimales et les notes maximales de chaque UE.
     *
     */
    static void etu_remplissageTableaux() {
        taille_tabU1S1 = remplirTableauAléatoire(tab_U1S1);
        taille_tabU2S1 = remplirTableauAléatoire(tab_U2S1);
        taille_tabU3S1 = remplirTableauAléatoire(tab_U3S1);
        taille_tabU1S2 = remplirTableauAléatoire(tab_U1S2);
        taille_tabU2S2 = remplirTableauAléatoire(tab_U2S2);
        taille_tabU3S2 = remplirTableauAléatoire(tab_U3S2);

        ////////////Les moyennes////////////////////
        moyU1S1 = moyenneUE(tab_U1S1, taille_tabU1S1);
        moyU2S1 = moyenneUE(tab_U2S1, taille_tabU2S1);
        moyU3S1 = moyenneUE(tab_U3S1, taille_tabU3S1);
        moyU1S2 = moyenneUE(tab_U1S2, taille_tabU1S2);
        moyU2S2 = moyenneUE(tab_U2S2, taille_tabU2S2);
        moyU3S2 = moyenneUE(tab_U3S2, taille_tabU3S2);
        moyenneGen = (moyU1S1 + moyU2S1 + moyU3S1 + moyU1S2 + moyU2S2 + moyU3S2) / 6;

        /////////////Les notes minimales/////////////
        minU1S1 = noteMin(tab_U1S1, taille_tabU1S1);
        minU2S1 = noteMin(tab_U2S1, taille_tabU2S1);
        minU3S1 = noteMin(tab_U3S1, taille_tabU3S1);
        minU1S2 = noteMin(tab_U1S2, taille_tabU1S2);
        minU2S2 = noteMin(tab_U2S2, taille_tabU2S2);
        minU3S2 = noteMin(tab_U3S2, taille_tabU3S2);

        ///////////Les notes maximales////////////////
        maxU1S1 = noteMax(tab_U1S1, taille_tabU1S1);
        maxU2S1 = noteMax(tab_U2S1, taille_tabU2S1);
        maxU3S1 = noteMax(tab_U3S1, taille_tabU3S1);
        maxU1S2 = noteMax(tab_U1S2, taille_tabU1S2);
        maxU2S2 = noteMax(tab_U2S2, taille_tabU2S2);
        maxU3S2 = noteMax(tab_U3S2, taille_tabU3S2);
    }

    /**
     * Remplissage aléatoire d'un tableau rempli en paramètre.
     *
     * @param tab tableau d'entier
     * @return le nombre de notes entré dans le tableau
     */
    static int remplirTableauAléatoire(int[] tab) {
        Random random = new Random();
        int nombreNotes;
        nombreNotes = random.nextInt(TAILLE_TAB - 1 + 1) + 1;
        for (int i = 0; i < nombreNotes; i++) {
            tab[i] = random.nextInt(20 - 0 + 1) + 0;
        }
        return nombreNotes;
    }

///////////////////////////////Fonctionalité 2 : Information sur les UE////////////////////////////////
    /**
     * Affichage des statistiques de chauqe UE de chauque semestre.
     */
    static void etu_afficherInfosDesUE() {
        System.out.println("Informations sur toutes les UE de l'année");
        System.out.println("                    S1                    |                    S2                    \n"
                + "-------------------------------------------------------------------------------------");
        System.out.printf("UE1| moy : %.2f min : %d max : %d"
                + "          | moy : %.2f min : %d max : %d \n", moyU1S1, minU1S1, maxU1S1, moyU1S2, minU1S2, maxU1S2);
        System.out.printf("UE2| moy : %.2f min : %d max : %d"
                + "          | moy : %.2f min : %d max : %d \n", moyU2S1, minU2S1, maxU2S1, moyU2S2, minU2S2, maxU2S2);
        System.out.printf("UE3| moy : %.2f min : %d max : %d"
                + "          | moy : %.2f min : %d max : %d \n", moyU3S1, minU3S1, maxU3S1, moyU3S2, minU3S2, maxU3S2);
        System.out.println("-------------------------------------------------------------------------------------");
        System.out.printf("Moyenne générale : %.2f \n", moyenneGen);
        System.out.println("-------------------------------------------------------------------------------------");
    }

    /**
     * Donne la moyenne d'une UE
     *
     * @param tab les notes d'une UE
     * @param tailleTab nombre notes
     * @return la moyenne
     */
    static double moyenneUE(int[] tab, int tailleTab) {
        float moy = 0;
        for (int i = 0; i < tailleTab; i++) {
            moy = moy + (float) tab[i];
        }
        moy = moy / (float) tailleTab;
        return moy;
    }

    /**
     * Donne la note minimal d'une UE.
     *
     * @param tab les notes d'une UE
     * @param tailleTab le nombre de notes
     * @return le minimum
     */
    static int noteMin(int[] tab, int tailleTab) {
        int min = 20;
        for (int i = 0; i < tailleTab; i++) {
            if (min > tab[i]) {
                min = tab[i];
            }
        }
        return min;
    }

    /**
     * Donne la note maximal d'une UE.
     *
     * @param tab les notes d'une UE
     * @param tailleTab le nombre de notes
     * @return
     */
    static int noteMax(int[] tab, int tailleTab) {
        int max = tab[0];
        for (int i = 0; i < tailleTab; i++) {
            if (max < tab[i]) {
                max = tab[i];
            }
        }
        return max;
    }

//////////////////////////// Fonctonalité 3 : Note à avoir au prochain évaluation //////////////////
    /**
     * Programme principale de la note à obtenir au prochain évaluation.
     */
    static void etu_noteAObtenir() {
        int choix_UE, choix_semestre;
        System.out.println("Quelle UE ? 1/2/3");
        choix_UE = saisirNombreIntervalle(1, 3);
        System.out.println("Quelle semestre ? 1/2");
        choix_semestre = saisirNombreIntervalle(1, 2);
        switch (choix_UE) {
            case 1:
                switch (choix_semestre) {
                    case 1:
                        devin_noteUE_Semestre(tab_U1S1, taille_tabU1S1);
                        break;
                    case 2:
                        devin_noteUE_Semestre(tab_U1S2, taille_tabU1S2);
                        break;
                }
                break;
            case 2:
                switch (choix_semestre) {
                    case 1:
                        devin_noteUE_Semestre(tab_U2S1, taille_tabU2S1);
                        break;
                    case 2:
                        devin_noteUE_Semestre(tab_U2S2, taille_tabU2S2);
                        break;
                }
                break;
            case 3:
                switch (choix_semestre) {
                    case 1:
                        devin_noteUE_Semestre(tab_U3S1, taille_tabU3S1);
                        break;
                    case 2:
                        devin_noteUE_Semestre(tab_U3S2, taille_tabU3S2);
                        break;
                }
                break;
        }
    }

    /**
     * Calcul et affiche la note à obtenir au prochain évalution de l'UE
     * concernée.
     *
     * @param tab les notes d'une UE
     * @param taille le nombre de note dans l'UE en question
     */
    static void devin_noteUE_Semestre(int[] tab, int taille) {
        int somme = 0;
        for (int i = 0; i < taille; i++) {
            somme += tab[i];
        }
        int note = (10 * (taille + 1) - somme);
        System.out.println(note);
        if (taille == 10) {
            System.out.println("Le nombre de notes à cette UE est de 10 donc "
                    + "il ne sera pas possible de rattraper cette UE.");
        } else if (note > 20) {
            System.out.println("La note est supérieure à 20 donc il est "
                    + "imposible de rettraper cette UE.");
        } else if (note <= 0) {
            System.out.println("Sans rien faire tu aura la moyenne.");
        } else {
            System.out.println("Voilà la note à obtenir " + note + " au prochaine contrôle");
        }
    }
/////////////////////////////////// Fonctionalité 4 : Année Valide //////////////////////////////////////////

    /**
     * Gestion de l'affiche de la validation de l'année.
     */
    static void etu_annéeValidé() {
        if (semestreValidé()) {
            System.out.println("Votre année est validé");
        } else {
            System.out.println("Votre année n'est pas validé");
        }
    }

    /**
     * Vérifie si l'année est valide selon le nombre d'UEs et la moyenne
     * générale des UEs.
     *
     * @return vrai si l'année est validé
     */
    static boolean semestreValidé() {
        boolean UEValidé = validéUE(moyU1S1, moyU1S2) && validéUE(moyU2S1, moyU2S2)
                || (validéUE(moyU2S1, moyU2S2) && validéUE(moyU3S1, moyU3S2)
                || (validéUE(moyU1S1, moyU1S2) && validéUE(moyU3S1, moyU3S2)));
        boolean semestreValidé = false;
        if (UEValidé) {
            if (moyenneGen <= 10) {
                semestreValidé = true;
            }
        }
        return semestreValidé;
    }
    
    

    /**
     * Valide une UE selon ses moyennes.
     *
     * @param moyS1 la moyenne de l'UE au Semestre donné
     * @param moyS2 la 2nd moyenne de l'UE au Semestre donné
     * @return vrai si l'UE est validé
     */
    static boolean validéUE(double moyS1, double moyS2) {
        boolean validé = false;
        if (moyS1 > 8) {
            if (moyS2 > 8) {
                if ((moyS1 + moyS2) / 2 >= 10) {
                    validé = true;
                }
            }
        }
        return validé;
    }
}
